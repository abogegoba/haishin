<?php $iine = app('App\Services\IineService'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12 text-center">
            <?php if($user->image!=null): ?>
            <img src="/storage/<?php echo e($user->image); ?>" style="height:15vh;object-fit:cover">
            <?php endif; ?>
        </div>
        <div class="col-12">
            <div class="row">
                <div class="col-3 text-right mt-2 d-flex align-items-center label">
                    <span style="font-size:14px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#000;width:100%">
                        ニックネーム
                    </span>
                </div>
                <div class="col-6 mt-2 pl-0">
                    <span style="font-size:16px;font-family: 'Kosugi Maru', sans-serif;font-weight:500;color:#ff1493;">
                        <?php echo e($user->name); ?>

                    </span>   
                </div>
                <div class="col-3 mt-2 pl-0">
                <?php if($iine->get($user->id) == 0): ?>
                    <span style="font-size:16px;font-family: 'Kosugi Maru', sans-serif;font-weight:500;color:#bbb;">
                    <a href="/iineon/<?php echo e($user->id); ?>">🤍</a> <?php echo e($iine->count($user->id)); ?>

                <?php else: ?>
                    <span style="font-size:16px;font-family: 'Kosugi Maru', sans-serif;font-weight:500;color:#f00;">
                    <a href="/iineoff/<?php echo e($user->id); ?>">💞</a> <?php echo e($iine->count($user->id)); ?>

                <?php endif; ?>
                    </span>   
                </div>
                <div class="col-3 text-right mt-2  label">
                    <span style="font-size:14px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#000;width:100%">
                        プロフィール
                    </span>
                </div>
                <div class="col-9 mt-2 pl-0" style="background:#ffffec">
                        <?php echo nl2br($user->information); ?>

                </div>
                <div class="col-12 mt-2 pl-0" style="background:#ffffec">
                        <a class="btn btn-info btn-block" href="https://rabitalk.jvideo.club:8444/?name=<?php echo e(Auth::id()); ?>&tel=<?php echo e($user->id); ?>&room=<?php echo e($user->id); ?>">電話をかける</a>
                </div>
                <div class="col-12 mt-2 pl-0" style="background:#ffffec">
                        <a class="btn btn-info btn-block" href="/message?room=<?php echo e($user->id); ?>">メッセージを送る</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/rabitalk.jvideo.club/resources/views/showprofile.blade.php ENDPATH**/ ?>