<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12">
<h1>特定商取引法に基づく表記</h1>
 <br>
<h2>運営会社</h2>
 <br>
合同会社RABI TALK<br>
 <br>
 <br>
<h2>所在地</h2>
 <br>
〒135-0091<br>
東京都港区台場1-1-1-1807<br>
 <br>
 <br>
<h2>お問合わせ先</h2>
 <br>
RABI TALKサポート<br>
メールアドレス support@rabitalk.com<br>
※連絡先電話番号についても、Emailアドレスまでご請求いただければ、遅滞なく開示いたします。<br>
 <br>
 <br>
<h2>販売業務責任者</h2>
 <br>
合同会社RABI TALK　山田恵<br>
 <br>
 <br>
<h2>販売価格</h2>
 <br>
対象となるデジタルコンテンツ(以下「コンテンツ」)ごとに表示されるポイントに対応する金額。<br>
※購入手続きの際に画面に表示されます。<br>
 <br>
 <br>
<h2>販売価格以外の費用</h2>
 <br>
パケット代等の携帯電話の利用に伴う通信費用及び電気通信回線の通信料金等(インターネット接続料金を含む)<br>
※料金は、お客様がご契約されている通信事業者等にお問い合わせください。<br>
 <br>
 <br>
<h2>販売条件</h2>
 <br>
各コンテンツに表示されるポイント数ごとに、１名のみ。<br>
 <br>
 <br>
<h2>代金のお支払時期</h2>
 <br>
コンテンツ提供の前<br>
 <br>
 <br>
<h2>代金のお支払方法</h2>
 <br>
お支払方法は、以下のいずれかよりお選びいただけます。<br>
・クレジットカードによる支払方法<br>
・Apple.Inc またはその子会社が提供する決済手段による支払方法（iOS用アプリケーションのみ）<br>
 <br>
 <br>
<h2>申込みの有効期限</h2>
 <br>
予め定められた各コンテンツの提供日時の前<br>
 <br>
 <br>
<h2>提供時期</h2>
 <br>
コンテンツは、お支払手続完了後、予め定められていた日時に直ちに提供いたします。<br>
 <br>
 <br>
<h2>返品について</h2>
 <br>
オンラインサービスであるという性質上、デジタルコンテンツやソフトウェアの購入後のお客様のご都合による返品やキャンセルはできません。<br>
 <br>
 <br>
<h2>不良品の取扱条件</h2>
 <br>
登録処理が不正に終わった場合は、速やかに修正致します。<br>
 <br>
 <br>
<h2>動作環境</h2>
 <br>
■Windowsをご利用の場合のブラウザ環境について<br>
Chrome 43以上<br>
 <br>
■Mac OS Xをご利用の場合のブラウザ環境について<br>
Chrome 43以上<br>
 <br>
■Android 端末のスペックについて<br>
Android 7.0 以上のOSが動作する端末<br>
Chrome 43以上<br>
 <br>
■iOS 端末のスペックについて<br>
iOS9.3 以上が動作するiPhone 端末<br>
 <br>
<br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/rabitalk.jvideo.club/resources/views/tokutei.blade.php ENDPATH**/ ?>