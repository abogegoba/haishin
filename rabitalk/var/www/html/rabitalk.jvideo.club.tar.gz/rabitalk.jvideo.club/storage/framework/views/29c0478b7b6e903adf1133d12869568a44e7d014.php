<META http-equiv="Refresh" content="0;URL=/top">

<?php /**PATH /var/www/html/rabitalk.jvideo.club/resources/views/errors/419.blade.php ENDPATH**/ ?>