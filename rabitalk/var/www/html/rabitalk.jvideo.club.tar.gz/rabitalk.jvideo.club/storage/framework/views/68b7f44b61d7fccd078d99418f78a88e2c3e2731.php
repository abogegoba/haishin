<?php $iine = app('App\Services\IineService'); ?>


<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-12">
            <div class="row">
                <div class="col-12 p-1">
                    <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#888;width:100%">
                        ● キャスト一覧
                    </span>
                </div>
                <?php $__currentLoopData = $loginusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-6 p-1">
                        <a href="/user/<?php echo e($user->id); ?>">
                            <div class="card">
                                <div class="card-header p-0">
                                    <img src="/storage/<?php echo e($user->image); ?>" style="width:100%;height:150px;object-fit: cover;">
                                    <div style="position:absolute;top:130px;right:10px">
                                        <?php if($iine->get($user->id) == 0): ?>
                                            <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:500;color:#bbb;">
                                            <a href="/iineonlist/<?php echo e($user->id); ?>">🤍</a> <?php echo e($iine->count($user->id)); ?>

                                            </span>  
                                        <?php else: ?>
                                            <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:500;color:#f00;">
                                            <a href="/iineofflist/<?php echo e($user->id); ?>">💞</a> <?php echo e($iine->count($user->id)); ?>

                                            </span>  
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-body p-0 pl-3">
                                    <div class="col-12 p-0">
                                        <?php switch($user->online):
                                            case (0): ?>
                                                <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#888;width:100%">
                                                    ● OFFLINE
                                                </span>
                                                <?php break; ?>
                                            <?php case (2): ?>
                                                <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#a55;width:100%">
                                                    ● 通話中
                                                </span>
                                                <?php break; ?>
                                            <?php case (1): ?>
                                                <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#5a5;width:100%">
                                                    ● ONLINE
                                                </span>
                                                <?php break; ?>
                                        <?php endswitch; ?>
                                    </div>
                                    <div class="col-12 p-0">
                                        <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#000;">
                                            <?php echo e($user->name); ?>

                                        </span>
                                    </div>
                                </div>
                            </div>
                        </a>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/rabitalk.jvideo.club/resources/views/senderlist.blade.php ENDPATH**/ ?>