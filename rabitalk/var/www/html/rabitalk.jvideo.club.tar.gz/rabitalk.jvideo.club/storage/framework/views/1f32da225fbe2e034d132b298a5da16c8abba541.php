<?php $usr = app('App\Services\UserService'); ?>
<div class="col-6 col-md-4 p-1">
                        <a href="/user/<?php echo e($project->user_id); ?>">
                            <div class="card">
                                <div class="card-header p-0">
                                    <img src="/storage/<?php echo e($project->image); ?>" style="width:100%;height:150px;object-fit: cover;">
                                    <div style="position:absolute;top:130px;right:10px">
                                        <?php if($iine->count($project->user_id) == 0): ?>
                                            <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:500;color:#bbb;">
                                            <a href="/iineontop/<?php echo e($project->user_id); ?>">🤍</a> <?php echo e($iine->count($project->user_id)); ?>

                                            </span>  
                                        <?php else: ?>
                                            <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:500;color:#f00;">
                                            <a href="/iineofftop/<?php echo e($project->user_id); ?>">💞</a> <?php echo e($iine->count($project->user_id)); ?>

                                            </span>  
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="card-body p-0 pl-3">
                                    <div class="col-12 p-0">
                                        <?php switch($usr->get($project->user_id)->online):
                                            case (0): ?>
                                                <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#888;width:100%">
                                                    ● OFFLINE
                                                </span>
                                                <?php break; ?>
                                            <?php case (2): ?>
                                                <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#a55;width:100%">
                                                    ● 通話中
                                                </span>
                                                <?php break; ?>
                                            <?php case (1): ?>
                                                <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#5a5;width:100%">
                                                    ● ONLINE
                                                </span>
                                                <?php break; ?>
                                        <?php endswitch; ?>
                                    </div>
                                    <div class="col-12 p-0">
                                        <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#000;">
                                            <?php echo e($usr->get($project->user_id)->name); ?>

                                        </span>
                                    </div>
                                    <div class="col-12 p-0">
                                        <span style="font-size:12px;font-family: 'Kosugi Maru', sans-serif;font-weight:400;color:#000;">
                                            <?php echo e($project->date); ?><br>
                                            <?php echo e($project->title); ?>

                                        </span>
                                    </div>
                                </div>
                            </div>
                        </a>

                    </div><?php /**PATH /var/www/html/rabitalk.jvideo.club/resources/views/components/plays.blade.php ENDPATH**/ ?>