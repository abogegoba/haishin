<META http-equiv="Refresh" content="0;URL=/home">

