<?php

namespace App\Http\Controllers;

use App\NagesenLog;
use Illuminate\Http\Request;

class NagesenLogController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\NagesenLog  $nagesenLog
     * @return \Illuminate\Http\Response
     */
    public function show(NagesenLog $nagesenLog)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\NagesenLog  $nagesenLog
     * @return \Illuminate\Http\Response
     */
    public function edit(NagesenLog $nagesenLog)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\NagesenLog  $nagesenLog
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, NagesenLog $nagesenLog)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\NagesenLog  $nagesenLog
     * @return \Illuminate\Http\Response
     */
    public function destroy(NagesenLog $nagesenLog)
    {
        //
    }
}
